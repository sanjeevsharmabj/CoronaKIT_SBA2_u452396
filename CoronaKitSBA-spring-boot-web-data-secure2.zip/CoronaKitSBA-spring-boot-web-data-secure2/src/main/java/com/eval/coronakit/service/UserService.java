package com.eval.coronakit.service;


import com.eval.coronakit.entity.Users;

public interface UserService {

	public Users getUserDetails(String username);
}
